﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace backup
{
    public partial class index : System.Web.UI.Page
    {
        public DataSet dataSet;
        protected void Page_Load(object sender, EventArgs e)
        {
            String searchSql;
            if (searchStr.Value == "" || searchStr.Value == null)
            {
                searchSql = "select * from article";
            }
            else
            {
                if (intercept(searchStr.Value)) // waf
                {
                    Response.Close();
                }
                searchSql = "select * from article where [content] like ('%" + searchStr.Value + "%')";
            }
            SqlConnection con = new SqlConnection("server=127.0.0.1;database=_backup;uid=test;pwd=test");
            SqlDataAdapter adapter = new SqlDataAdapter(searchSql, con);
            dataSet = new DataSet();
            adapter.Fill(dataSet);
        }

        public DataSet GetDataSet()
        {
            return this.dataSet;
        }

        protected Boolean intercept(String searchStr)
        {
            String pattern = @"/\*.*?\*/|\w+?\s*\(.*?\)|order\s+by|union\s+select|union\s+all|alter\s+database|"
                            + @"create\s+table|backup\s+database|insert\s+into|backup\s+log|drop\s+table";
            if(Regex.IsMatch(searchStr, pattern, RegexOptions.IgnoreCase))
            {
                return true;
            }
            return false;
        }

    }
}